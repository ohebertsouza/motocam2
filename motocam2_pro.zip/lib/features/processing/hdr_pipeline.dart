
class HDRPipeline {
  Future<void> processMultiFrameHDR() async {
    // TODO:
    // Capture multiple frames
    // Align frames
    // Merge exposure maps
    // Recover highlights
  }
}
