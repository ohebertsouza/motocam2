
enum PhotoStyle {
  natural,
  cinematic,
  warm,
  cool,
  contrast,
  soft,
}
