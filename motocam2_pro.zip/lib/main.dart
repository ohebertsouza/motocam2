
import 'package:flutter/material.dart';
import 'ui/home_page.dart';

void main() {
  runApp(const MotoCam2App());
}

class MotoCam2App extends StatelessWidget {
  const MotoCam2App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MotoCam2',
      theme: ThemeData.dark(),
      home: const HomePage(),
    );
  }
}
